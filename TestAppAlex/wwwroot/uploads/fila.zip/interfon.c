#include "defs.h"
#include "iofn.h"

#define FMSG   0
#define WAIT   1
#define RING   2
#define OPEN   3
#define CODE1  4
#define CODE2  5
#define CODE3  6
#define ERR    7

void systime_init();
unsigned long get_systime();

int main(){
   char code_prev = NOKEY;
   char code_now  = NOKEY;
   unsigned long ts_now = 0;
   unsigned long ts_ante = 0; 
   char kbcode, kbhit = 0;
   
   unsigned long ts_start_fsm = 0;
   char cod[]="123"; //sau int cod = 123;
   char buf[4];
   char state = FMSG;
   
   initLCD();
   systime_init();
   
   PORTA = 0x00;
   
   while(1){
      ts_now = get_systime();
      if(ts_now - ts_ante >= KB_DELAY){ //citirile se fac din 50 ms in 50 ms
         code_now  = kbscan();
         
         if( code_prev == NOKEY && code_now != NOKEY){
            kbcode = code_now;
            kbhit = 1;
         }
         code_prev = code_now;
         ts_ante = ts_now;
      }
      
      //SFSM
      switch (state){
         case FMSG:
         clrLCD();
         putsLCD("Suna la 1..8,");
         gotoLC(2,1);
         putsLCD("C pentru cod:");
         state = WAIT;
         break;
         
         case WAIT:
         if(kbhit){
            kbhit=0;
            if ('C'==kbcode){
               clrLCD();
               putsLCD("Cod =");
               state = CODE1;
            }
            if (kbcode>='1' && kbcode <= '8'){
               clrLCD();
               putsLCD("Suna la ");
               putchLCD(kbcode);
               state = RING;
               ts_start_fsm = get_systime();
            }
         }
         break;
         
         case RING:
         ... 
         break;
                  
         case CODE1:
         if(kbhit){
            kbhit=0;
            if (kbcode>='0' && kbcode <= '9'){
               buf[0]=kbcode;
               putchLCD('*');
               state = CODE2;
            }
            else{
               state = FMSG;
            }
         }
         break;
         
         case CODE2:
         ...
         break;
         
         case CODE3:
         ...
         break;
         
         case OPEN:
         ...
         break;
         
         case ERR:
         ...
         break;
         
      }//end switch
   } //end while(1)
}//end main
